using bag;
using BagMenu;
namespace TestOOPProject
{
    [TestClass]
    public class BagTesting
    {
        [TestMethod]
        public void Exceptions()
        {
            Bag bag = new Bag();

            Assert.ThrowsException<Bag.EmptyBagException> (() => bag.RemoveElement((50,40)));

            Assert.ThrowsException<Bag.EmptyBagException>(() => bag.LargestElement());

            Assert.ThrowsException<Bag.EmptyBagException>(() => bag.GetFrequency(50));

            Assert.ThrowsException<Bag.EmptyBagException>(() => bag.PrintBag());

            bag.InsertElement((20, 30));

            Assert.ThrowsException<Bag.NonExistentElement>(() => bag.RemoveElement((50,40)));

            Assert.ThrowsException<Bag.NonExistentElement>(() => bag.GetFrequency(50));

            bag.InsertElement((50,39));

            Assert.ThrowsException<Bag.UnsufficientFrequencyException>(()=> bag.RemoveElement((50, 40))); 
            
            Assert.ThrowsException<Bag.WrongFrequencyException>(() => bag.InsertElement((50,-2)));

            Assert.ThrowsException<Bag.WrongFrequencyException>(() => bag.RemoveElement((50, -2)));
        }
        [TestMethod]
        public void LargestElement()
        {
            Bag bag = new Bag();

            bag.InsertElement((1, 1));
            bag.InsertElement((123,1));

            Assert.AreEqual(123, bag.LargestElement());

            bag.InsertElement((122, 2));

            Assert.AreNotEqual(122, bag.LargestElement());

            bag.RemoveElement((123, 1));
            Assert.IsTrue(123 != bag.LargestElement());
        }
        [TestMethod]
        public void GetFrequency()
        {
            Bag bag = new Bag();

            bag.InsertElement((1, 1));
            Assert.AreEqual(bag.GetFrequency(1),1);

            bag.InsertElement((1,2));
            Assert.IsFalse(bag.GetFrequency(1) == 2 || bag.GetFrequency(1)==1);

            bag.InsertElement((2, 3));
            Assert.IsNotNull(bag.GetFrequency(2));
        }
        [TestMethod]
        public void InsertElement()
        {
            Bag bag = new Bag();

            var element = (5, 3);
            bag.InsertElement(element);

            Assert.IsTrue(bag.LargestElement().Equals(element.Item1));

            Assert.IsTrue(bag.GetFrequency(5).Equals(element.Item2));

            var max = (5,3);
            Assert.AreEqual(max.Item1, bag.LargestElement());
        }

        [TestMethod]
        public void RemoveElement()
        {
            Bag bag = new Bag();

            bag.InsertElement((5, 1));
            bag.RemoveElement((5, 1));


            Bag bag2 = new Bag();
            Assert.AreEqual(bag, bag2);
            Assert.AreEqual(0, bag.Size);

            bag.InsertElement((5, 1));
            bag.InsertElement((6, 1));
            bag.RemoveElement((6, 1));
            Assert.AreNotEqual(0, bag.Size);

            Assert.IsFalse(bag.Equals(bag2));

        }
    }
}