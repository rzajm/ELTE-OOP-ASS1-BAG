﻿
namespace BagTesting
{
    internal class TestClassAttribute : Attribute
    {
    }
}