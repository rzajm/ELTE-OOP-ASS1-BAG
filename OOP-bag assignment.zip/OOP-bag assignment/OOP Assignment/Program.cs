﻿using bag;
using BagMenu;

namespace OOP_Assignment
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Menu menu = new Menu(); 
            menu.Start();
           
        }
    }
}