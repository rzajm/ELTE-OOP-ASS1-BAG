﻿using System;
using bag;
using static bag.Bag;
namespace BagMenu
{
        #region Menu
    public class Menu
    {
        Bag bag = new Bag();

        public Menu() { }

        public void Start()
        {
            int num;
            
            do
            {
                PrintMenu();
                try
                {
                    num = int.Parse(Console.ReadLine());
                }
                catch (System.FormatException) { num = -1;}
                if (num > 5 || num < 0)
                {
                    Console.WriteLine("Please insert a correct menu option!\n");
                }
                else
                {
                    switch (num)
                    {
                        case 1:
                            AddElem();
                            break;
                        case 2:
                            DeleteElem();
                            break;
                        case 3:
                            GiveFreq();
                            break;
                        case 4:
                            BiggestElem();
                            break;
                        case 5:
                            Print();
                            break;
                    }
                }

            } while (num != 0);

        }
        #endregion

        #region Menu functions

        static private void PrintMenu()
        {
            Console.WriteLine(" 0. - Quit");
            Console.WriteLine(" 1. - Add an element");
            Console.WriteLine(" 2. - Remove an element");
            Console.WriteLine(" 3. - Get frequency of an element");
            Console.WriteLine(" 4. - Get the largest element of the bag");
            Console.WriteLine(" 5. - Print the bag");
            Console.Write(" Choose: ");

        }

        private void AddElem()
        {
            int temp = 0;
            int YesOrNo = 1;
            bool validInput = false;
            while (!validInput&&YesOrNo==1)
            {
                try
                {
                    Console.WriteLine("Please give the element that you want to add:");
                    int elem = int.Parse(Console.ReadLine());
                    Console.WriteLine("Please tell us how many of this element you want to add:");
                    int freq = int.Parse(Console.ReadLine());
                    bag.InsertElement((elem, freq));
                    Console.WriteLine($"{freq} of element {elem} added to the bag!\n");
                    validInput = true;
                    break;
                }
                catch (System.FormatException)
                {

                    Console.WriteLine("Please insert an argument in a correct type!");
                    Console.WriteLine("Do you still want to add an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }
                catch (System.ArgumentNullException)
                {

                    Console.WriteLine("Please insert a non-null argument!");
                    Console.WriteLine("Do you still want to add an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }
                catch (WrongFrequencyException ex)
                {

                    Console.WriteLine(ex.Message);
                    Console.WriteLine("Do you still want to add an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else 
                    {
                        YesOrNo = temp; 
                    }

                }


            }
            
        }

        private void DeleteElem()
        {
            int YesOrNo = 1;
            int temp;
            bool validInput = false;
            while (!validInput && YesOrNo==1)
            {
                try
                {
                    Console.WriteLine("Please give the element that you want to remove:");
                    int elem = int.Parse(Console.ReadLine());
                    Console.WriteLine("Please tell us how many of this element you want to remove:");
                    int freq = int.Parse(Console.ReadLine());
                    bag.RemoveElement((elem, freq));
                    Console.WriteLine($"{freq} of element {elem} removed from the bag!\n");
                    break;
                }
                catch (System.FormatException)
                {

                    Console.WriteLine("Please insert an argument in a correct type!");
                    Console.WriteLine("Do you still want to remove an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }
                catch (EmptyBagException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("Do you still want to remove an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }


                }
                catch (NonExistentElement exc)
                {
                    Console.WriteLine(exc.Message);
                    Console.WriteLine("Do you still want to remove an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }
                catch (UnsufficientFrequencyException exce)
                {
                    Console.WriteLine(exce.Message);
                    Console.WriteLine("Do you still want to remove an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }
                }
                catch (WrongFrequencyException excep)
                {

                    Console.WriteLine(excep.Message);
                    Console.WriteLine("Do you still want to add an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }

            }
            

        }
        private void BiggestElem()
        {
            try
            {
                Console.WriteLine("Currently, the largest element in the bag is: " + bag.LargestElement());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
        private void GiveFreq()
        {
            int temp = 0;
            int YesOrNo = 1;
            bool validInput = false;
            while (!validInput&&YesOrNo==1)
            {
                try
                {
                    Console.WriteLine("Please insert the element you want to find the frequency of: ");
                    int elem = int.Parse(Console.ReadLine());
                    if (bag.LargestElement() != null)
                    {
                        Console.Write($"The frequency of {elem} is: ");
                    }
                    Console.WriteLine(bag.GetFrequency(elem));
                    break;

                }
                catch (System.FormatException)
                {

                    Console.WriteLine("Please insert an argument in a correct type!");
                    Console.WriteLine("Do you still want to find the frequency of an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }

                }
                catch (EmptyBagException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("Do you still want to give the frequency of an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }
                }
                catch (NonExistentElement exe)
                {
                    Console.WriteLine(exe.Message);
                    Console.WriteLine("Do you still want to give the frequency of an element? 0-No  1-Yes");
                    temp = int.Parse(Console.ReadLine());
                    if (temp != 1 && temp != 0)
                    {
                        Console.WriteLine("Please insert a correct option just 0 or 1!\n");
                        temp = int.Parse(Console.ReadLine());
                    }
                    else { YesOrNo = temp; }
                }

            }
     
        }
        private void Print()
        {
            try
            {
                bag.PrintBag();
                Console.WriteLine("\n");

            }
            catch (EmptyBagException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        #endregion
    }
}