﻿namespace bag
{
    public class Bag
    {
        #region Attributes
        private List<(int, int)> bag;
        #endregion

        #region Constructors
        public Bag()
        {
            bag = new List<(int, int)>();
        }
        #endregion

        #region Methods
        public void InsertElement((int,int) elem)
        {   if (elem.Item2 <= 0) throw new WrongFrequencyException("Frequency cannot be 0 or negative!");
            if (Exist(elem.Item1) == false)
                bag.Add((elem));
            else
                for (int i = 0; i < bag.Count; i++)
                {
                    if (bag[i].Item1 == elem.Item1)
                        bag[i] = (elem.Item1, (bag[i].Item2+elem.Item2));
                }

           
        }

        public void RemoveElement((int, int) elem)
        {
            if (elem.Item2 <= 0) throw new WrongFrequencyException("Frequency cannot be 0 or negative!");
            if (bag.Count == 0) throw new EmptyBagException("Bag is empty!");



            if (bag.Count != 0 && !Exist(elem.Item1)) throw new NonExistentElement("Bag does not contain such an element!");
            if (Exist(elem.Item1))
            {
                for (int i = 0; i < bag.Count; i++)
                {
                    if (bag[i].Item1 == elem.Item1 && bag[i].Item2 < elem.Item2) throw new UnsufficientFrequencyException($"The frequency of the element is less than the amount you want to remove! There is/are only {elem.Item2} of the element in the bag!");
                    if (bag[i].Item1 == elem.Item1 && bag[i].Item2 == elem.Item2)
                    {
                        bag.Remove(bag[i]);
                        break;
                    }
                    if (bag[i].Item1==elem.Item1 && bag[i].Item2>elem.Item2)
                    {
                        bag[i] = (elem.Item1, bag[i].Item2 - elem.Item2);
                    }
                }
            }
            
        }

        public int LargestElement()
        {
            if (bag.Count == 0) throw new EmptyBagException("Bag is empty!");
            int largest = int.MinValue;
            for (int i = 0; i < bag.Count; i++)
            {
                if (bag[i].Item1 > largest)
                {
                    largest = bag[i].Item1;
                }
            }

            return largest;
        }

        public int GetFrequency(int elem)
        {
            if (bag.Count == 0) throw new EmptyBagException("Bag is empty!");
            if (Exist(elem) == false) throw new NonExistentElement("Element does not exist in the bag!");
            int freq = 0;
            for (int i = 0; i < bag.Count; i++)
            {
                if (bag[i].Item1 == elem)
                {
                    freq = bag[i].Item2;

                }
            }
            return freq; 
        }

        public int Size
        {
            get
            {
                return bag.Count;
            }
        }

    private bool Exist(int elem)
        {
            for (int i = 0; i < bag.Count; i++)
            {
                if (bag[i].Item1 == elem)
                {
                    return true;
                }
            }

            return false;
        }
        public void PrintBag()
        {
            Console.WriteLine("\nBag:");
            if (bag.Count == 0) throw new EmptyBagException("Bag is empty!");

            foreach (var item in bag)
            {
                Console.Write($"({item.Item1},{item.Item2}) ");
            }
        }

        public override bool Equals(Object? obj)
        {
            if (obj == null || !(obj is Bag))
                return false;
            else
            {
                Bag? b = obj as Bag;
                if (b!.Size != Size) return false;
                for (int i = 0; i < b.Size; i++)
                {
                    if (b.bag[i] != this.bag[i]) return false;
                }
                return true;
            }
        }
        #endregion

        #region Exceptions
        public class EmptyBagException : Exception
        {
            public EmptyBagException(string message) : base(message)
            {

            }
        }
        public class NonExistentElement : Exception
        {
            public NonExistentElement(string message) : base(message) { }
        }
        public class UnsufficientFrequencyException : Exception
        {
            public UnsufficientFrequencyException(string message) : base(message) { }
        }
        public class WrongFrequencyException : Exception
        {
            public WrongFrequencyException(string message) : base(message) { }
        }
        #endregion
    }
}