﻿
namespace BagTesting
{
    internal class TestMethodAttribute : Attribute
    {
    }
}